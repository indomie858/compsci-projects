/**
 * @author Gaven Grantz
 * September 20, 2018
 * CS282 Project #0 - Flat Files
 * Source - Project0.java
 * Description: This is a Java program that creates an array of Record objects,
 * reads data from a file, and fills the Record object attributes. After the 
 * user enters a negative value, the data in the Record objects will be transferred
 * to FixedRecord objects. The data in the FixedRecord objects are then written 
 * to a text file.
 */


package project0;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;



public class Project0 {

    public Project0() {
    }
    
    
    public static void main(String[] args) throws FileNotFoundException{
        final int RECORDARRLENGTH = 10;
        Record[] recordArray = new Record[RECORDARRLENGTH]; //creates Record array
        
        Project0 projectObj = new Project0(); //creates instance of Project0
        recordArray = projectObj.readFileToRecord(recordArray); //invokes readFileToRecord and passes recordArray as argument
        
        //recordToFixedRecord(recordArray);
        
        Scanner input = new Scanner(System.in); //keyboard input
        int recordIndex = 0;
        
        System.out.print("Welcome to your database.\nPlease enter a record number(0-4): ");
        
        while(recordIndex >= 0){ //loop asking user input for record number. Exit loop by entering a negative number
            try{
               recordIndex = input.nextInt();  //exception handling
            } catch (Exception e){
               System.out.print("Invalid index. Please enter a record number(0-4): ");
            }
            if (recordIndex > 4){
               System.out.print("Invalid index. Please enter a record number(0-4): ");
            } else if (recordIndex < 0){
                break;
            } else {
                recordArray[recordIndex].printRecord(recordIndex);
                System.out.print("Please enter a record number(0-4), or enter a negative value to exit: ");
            }
        }
        
        System.out.println("------End Database-----"); //end of records
        
        System.out.print("\nPlease enter a record size(80-128): "); //start of fixed records
        
        //String inputRecordSize = input.nextLine();
        
        final int FIXEDRECORDARRAYLENGTH = 10;
        FixedRecord[] fixedRecordArray = new FixedRecord[FIXEDRECORDARRAYLENGTH]; //created a array of FixedRecord obj
        
        fixedRecordArray = projectObj.recArrToFixedRecArr(recordArray, fixedRecordArray);
        //System.out.print(fixedRecordArray[1].getFirstName());
        
        //System.out.println(fixedRecordArray[1].getFirstName().length);
        
        projectObj.writeFixedRecordToFile(fixedRecordArray);
    }
    
    
    //This method reads the data from a text file, creates Record objects, and stores into a Record array
    private Record[] readFileToRecord(Record[] recArray) throws FileNotFoundException{
        String fileName = new String("Project0_data.txt");
        File fileObject = new File(fileName);
        Scanner input = new Scanner(fileObject);  //reads data from fileObject
        
        int lineCount = 5;
        String lineData;
        for (int i = 0; i < lineCount; i++){  //assigns data to variables, then creates Record objs and stores into array
            
            lineData = input.nextLine(); 
            String firstName, lastName, email, color;
            int idNumber;
            double balance;

            String[] data = lineData.split(", ");  //separates text data from file into fields
            firstName = data[0];
            lastName = data[1];
            email = data[2];
            idNumber = Integer.parseInt(data[3]);
            color = data[4];
            balance = Double.parseDouble(data[5]);

            /*  DEBUGGING PURPOSES
            //System.out.println(lineData);
            System.out.println(firstName);
            System.out.println(lastName);
            System.out.println(email);
            System.out.println(idNumber);
            System.out.println(color);
            System.out.println(balance);
            */

            recArray[i] = createRecord(firstName, lastName, email, idNumber, color, balance);
        }
        input.close();
        return recArray;
    }
    
    //This method creates Record objects. This method is called in readFileToRecord().
    private Record createRecord(String firstName, String lastName, String email, 
            int idNumber, String color, double balance){
        
        Record recordObj = new Record(firstName, lastName, email, idNumber, color, balance);
        
        return recordObj;
    }
    
    
    //This method adds space characters to FixedRecord fields
    private String padRight(String field, int fieldLength) {
        if (field.length() < fieldLength) {
            for (int i = field.length(); i < fieldLength; i++) {
                field += " ";
            }
        }
        return field;
    }
    
    
    //This method converts Record objects to FixedRecord objects
    private FixedRecord recordToFixedRecord(Record recObj){
        
        final int FIRSTNAMELENGTH = 10;
        final int LASTNAMELENGTH = 15;
        final int EMAILLENGTH = 25;
        final int IDNUMBERLENGTH = 10;
        final int COLORLENGTH = 10;
        final int BALANCELENGTH = 10;
        
        String firstName = recObj.getFirstName();
        String lastName = recObj.getLastName();
        String email = recObj.getEmail();
        String idNumber = Integer.toString(recObj.getIdNumber());
        String color = recObj.getColor();
        String balance = Double.toString(recObj.getBalance());
        
        firstName = padRight(firstName, FIRSTNAMELENGTH);
        lastName = padRight(lastName, LASTNAMELENGTH);
        email = padRight(email, EMAILLENGTH);
        idNumber = padRight(idNumber, IDNUMBERLENGTH);
        color = padRight(color, COLORLENGTH);
        balance = padRight(balance, BALANCELENGTH);
        
        //System.out.println("firstname padright length" + firstName.length());
        
        char[] firstNameArr = firstName.toCharArray();
        char[] lastNameArr = lastName.toCharArray();
        char[] emailArr = email.toCharArray();
        char[] idNumberArr = idNumber.toCharArray();
        char[] colorArr = color.toCharArray();
        char[] balanceArr = balance.toCharArray();
        
        FixedRecord fixedRecObj = new FixedRecord(firstNameArr, lastNameArr, emailArr,
            idNumberArr, colorArr, balanceArr);
        
        return fixedRecObj;
    }
    
    //This method converts Record[] to FixedRecord[]
    private FixedRecord[] recArrToFixedRecArr(Record[] recArr, FixedRecord[] fixedRecArr){
        int numLinesData = 5;
        FixedRecord fixedRecObj = new FixedRecord();
        
        for (int i = 0; i < numLinesData; i++){
            fixedRecObj = recordToFixedRecord(recArr[i]);
            fixedRecArr[i] = fixedRecObj;
        }
        
        return fixedRecArr;
    }
    
    
    //This method writes the FixedRecord objects to a text file
    private void writeFixedRecordToFile(FixedRecord[] fixedRecArr) throws FileNotFoundException{
        String fileName = "project0_FixedRecord_data.txt";
        File fileObject = new File(fileName);
        PrintWriter output = new PrintWriter(fileObject);
        
        for (int i = 0; i < 5; i++){  
            char[] firstName = fixedRecArr[i].getFirstName();
            char[] lastName = fixedRecArr[i].getLastName();
            char[] email = fixedRecArr[i].getEmail();
            char[] idNumber = fixedRecArr[i].getIdNumber();
            char[] color = fixedRecArr[i].getColor();
            char[] balance = fixedRecArr[i].getBalance();
            
            output.print(firstName);
            output.print(lastName);
            output.print(email);
            output.print(idNumber);
            output.print(color);
            output.println(balance);
        }
        
        output.close();
    }
}
