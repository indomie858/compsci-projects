/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PathDirectory;

import java.io.*;
import java.util.Scanner;

////////////////////////////////////////////////////////////////
public class PathApp {

    public static void main(String[] args) {
        Graph theGraph = new Graph();
        theGraph.addVertex('A'); // 0 (start)
        theGraph.addVertex('C'); // 2
        theGraph.addVertex('B'); // 1
        theGraph.addVertex('D'); // 3
        theGraph.addVertex('E'); // 4
        theGraph.addEdge(0, 1, 50); // AB 50
        theGraph.addEdge(0, 3, 80); // AD 80
        theGraph.addEdge(1, 2, 60); // BC 60
        theGraph.addEdge(1, 3, 90); // BD 90
        theGraph.addEdge(2, 4, 40); // CE 40
        theGraph.addEdge(3, 2, 20); // DC 20
        theGraph.addEdge(3, 4, 70); // DE 70
        theGraph.addEdge(4, 1, 50); // EB 50
        System.out.println("Shortest paths");
        theGraph.path(); // shortest paths
        System.out.println();
        
               while (true) {

            System.out.print("Enter first letter of ");

            System.out.print("read, show, insert, find, change, or quit: ");
            
            

            char menuInput = ' ';

        
        switch (menuInput){
            case 'a':
                break;
            case 'd':
                break;
            case 'f':
                break;
            case 'q':
                break;
        }
        
        }
        
    } // end main()
    
    
    
} // end class PathApp
////////////////////////////////////////////////////////////////
